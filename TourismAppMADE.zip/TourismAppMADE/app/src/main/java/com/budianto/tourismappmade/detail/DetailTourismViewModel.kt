package com.budianto.tourismappmade.detail

import androidx.lifecycle.ViewModel
import com.budianto.tourismappmade.core.domain.model.Tourism
import com.budianto.tourismappmade.core.domain.usecase.TourismUseCase

class DetailTourismViewModel(private val tourismUseCase: TourismUseCase) : ViewModel() {

    fun setFavoriteTourism(tourism: Tourism, newState: Boolean) = tourismUseCase.setFavoriteTourism(tourism, newState)
}