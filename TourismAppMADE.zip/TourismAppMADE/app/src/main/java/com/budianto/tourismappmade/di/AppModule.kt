package com.budianto.tourismappmade.di

import com.budianto.tourismappmade.core.domain.usecase.TourismInteractor
import com.budianto.tourismappmade.core.domain.usecase.TourismUseCase
import com.budianto.tourismappmade.detail.DetailTourismViewModel
import com.budianto.tourismappmade.home.HomeViewModel
import org.koin.android.viewmodel.dsl.viewModel
import org.koin.dsl.module


val useCaseModule = module {
    factory<TourismUseCase> { TourismInteractor(get()) }
}

val viewModelModule = module {
    viewModel { HomeViewModel(get()) }
    viewModel { DetailTourismViewModel(get()) }
}