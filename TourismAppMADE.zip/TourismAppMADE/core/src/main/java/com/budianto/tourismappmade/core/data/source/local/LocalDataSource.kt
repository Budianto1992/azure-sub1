package com.budianto.tourismappmade.core.data.source.local

import com.budianto.tourismappmade.core.data.source.local.entity.TourismEntity
import com.budianto.tourismappmade.core.data.source.local.room.TourismDao
import kotlinx.coroutines.flow.Flow

class LocalDataSource(val tourismDao: TourismDao){


    fun getAllTourism(): Flow<List<TourismEntity>> = tourismDao.getAllTourism()

    fun getFavoriteTourism(): Flow<List<TourismEntity>> = tourismDao.getFavoriteTourism()

    suspend fun insertTourism(tourismEntities: List<TourismEntity>) = tourismDao.insertTourism(tourismEntities)

    fun updateTourism(tourismEntity: TourismEntity, newState: Boolean){
        tourismEntity.isFavorite = newState
        tourismDao.updateFavoriteTourism(tourismEntity)
    }
}