package com.budianto.tourismappmade.core.domain.repository

import com.budianto.tourismappmade.core.data.Resource
import com.budianto.tourismappmade.core.domain.model.Tourism
import kotlinx.coroutines.flow.Flow

interface ITourismRepository {

    fun getAllTourism(): Flow<Resource<List<Tourism>>>

    fun getFavoriteTourism(): Flow<List<Tourism>>

    fun setFavoriteTourism(tourism: Tourism, state: Boolean)
}