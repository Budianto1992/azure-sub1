package com.budianto.tourismappmade.core.domain.usecase

import com.budianto.tourismappmade.core.data.Resource
import com.budianto.tourismappmade.core.domain.model.Tourism
import kotlinx.coroutines.flow.Flow

interface TourismUseCase {

    fun getAllTourism(): Flow<Resource<List<Tourism>>>
    fun getFavoriteTourism(): Flow<List<Tourism>>
    fun setFavoriteTourism(tourism: Tourism, state: Boolean)
}