package com.budianto.tourismappmade.core.utils

import com.budianto.tourismappmade.core.data.source.local.entity.TourismEntity
import com.budianto.tourismappmade.core.data.source.remote.response.TourismResponse
import com.budianto.tourismappmade.core.domain.model.Tourism

object DataMapper {

    fun mapResponseToEntities(input: List<TourismResponse>): List<TourismEntity>{
        val tourismList = ArrayList<TourismEntity>()
        input.map {
            val tourism = TourismEntity(
                tourismId = it.id,
                name = it.name,
                description = it.description,
                address = it.address,
                latitude = it.latitude,
                longitude = it.longitude,
                like = it.like,
                image = it.image,
                isFavorite = false
            )

            tourismList.add(tourism)
        }

        return tourismList
    }

    fun mapEntitiesToDomain(input: List<TourismEntity>): List<Tourism> =
        input.map {
            Tourism(
                tourismId = it.tourismId,
                name = it.name,
                description = it.description,
                address = it.address,
                latitude = it.latitude,
                longitude = it.longitude,
                like = it.like,
                image = it.image,
                isFavorite = it.isFavorite
            )
        }

    fun mapDomainToEntites(input: Tourism) = TourismEntity(
        tourismId = input.tourismId,
        name = input.name,
        description = input.description,
        address = input.address,
        latitude = input.latitude,
        longitude = input.longitude,
        like = input.like,
        image = input.image,
        isFavorite = input.isFavorite
    )
}